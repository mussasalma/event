<template>
  <nav class="navbar navbar-expand navbar-light navbar-bg">
    <a class="sidebar-toggle js-sidebar-toggle">
      <i class="hamburger align-self-center"></i>
    </a>

    <div class="navbar-collapse collapse">
      <ul class="navbar-nav navbar-align">
        <!-- <li class="nav-item dropdown">
          <a
            class="nav-link dropdown-toggle d-none d-sm-inline-block"
            href="#"
            data-bs-toggle="dropdown"
          >
            <span class="text-dark"><i class="bi bi-power"></i></span>
          </a>
          <div class="dropdown-menu dropdown-menu-end">
            <router-link class="dropdown-item" to="/profile">
              <span><i class="bi bi-person align-middle"></i></span> Profile</router-link
            >
            <router-link class="dropdown-item" to="/"
              ><span><i class="bi bi-pie-chart"></i></span> Analytics</router-link
            >
            <div class="dropdown-divider"></div>
            <router-link class="dropdown-item" to="/auth/login"
              ><span><i class="bi bi-box-arrow-right"></i></span> Log out</router-link
            >
          </div>
        </li> -->
      </ul>
    </div>
  </nav>
</template>
