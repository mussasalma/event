<template>
  <footer class="footer">
    <div class="container-fluid">
      <div class="row text-muted">
        <div class="col-6 text-start">
          <p class="mb-0">
            <span class="text-muted" href="https://adminkit.io/" target="_blank"
              ><strong>Attendance</strong></span
            >
            -
            <span class="text-muted" href="https://adminkit.io/" target="_blank"
              ><strong>System Dashboard</strong></span
            >
          </p>
        </div>
        <div class="col-6 text-end">
          <p>date and time</p>
        </div>
      </div>
    </div>
  </footer>
</template>
